import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyservService {

  constructor(private http : HttpClient) { }

  baseurl : String="http://localhost:8080";

  getText()
  {
    return this.http.get(this.baseurl +"/api/hello");
  }

}
