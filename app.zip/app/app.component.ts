import { Component } from '@angular/core';
import { MyservService } from './myserv.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-spring';

  text : Object;

  constructor(private abc: MyservService){ }

  getData()
  {
    this.abc.getText().subscribe(abc =>this.text=abc);  
  }
}
